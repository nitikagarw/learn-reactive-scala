Use the Sender

Please refer to the instructions in the Lightbend Academy.
