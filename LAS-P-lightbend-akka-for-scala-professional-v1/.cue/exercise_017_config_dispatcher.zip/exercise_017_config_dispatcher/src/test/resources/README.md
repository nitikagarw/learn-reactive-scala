Configure a Dispatcher

Please refer to the instructions in the Lightbend Academy.
